CREATE TABLE [sales].[dim_product] (

	[Product_ID] int NOT NULL, 
	[Product] varchar(max) NULL, 
	[Product_Category] varchar(max) NULL
);