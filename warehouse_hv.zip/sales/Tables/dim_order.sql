CREATE TABLE [sales].[dim_order] (

	[Order_ID] varchar(max) NULL, 
	[Order_Date_ID] int NULL, 
	[Shipping_Date_ID] int NULL, 
	[Ship_Mode] varchar(max) NULL, 
	[Order_Priority] varchar(max) NULL, 
	[Aging] int NULL
);