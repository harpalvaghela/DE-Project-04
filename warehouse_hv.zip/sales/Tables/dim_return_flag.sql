CREATE TABLE [sales].[dim_return_flag] (

	[Return_ID] bigint NULL, 
	[Return_Description] varchar(max) NULL
);