CREATE TABLE [sales].[dim_sales_return] (

	[Order_ID] varchar(max) NULL, 
	[Customer_Name] varchar(max) NULL, 
	[Sales_Amount] float NULL, 
	[Return_ID] int NOT NULL
);