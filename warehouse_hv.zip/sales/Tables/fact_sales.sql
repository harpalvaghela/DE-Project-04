CREATE TABLE [sales].[fact_sales] (

	[Order_ID] varchar(max) NULL, 
	[Customer_ID] varchar(max) NULL, 
	[Segment_ID] int NULL, 
	[Product_ID] int NULL, 
	[Order_Date_ID] int NULL, 
	[Shipping_Date_ID] int NULL, 
	[Sales] float NULL, 
	[Profit] float NULL, 
	[Quantity] int NULL, 
	[Discount] float NULL, 
	[Shipping_Cost] float NULL, 
	[Return_ID] int NULL
);