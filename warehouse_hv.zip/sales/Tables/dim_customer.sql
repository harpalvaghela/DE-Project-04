CREATE TABLE [sales].[dim_customer] (

	[Customer_ID] varchar(max) NULL, 
	[Customer_Name] varchar(max) NULL, 
	[Segment_ID] int NULL, 
	[City] varchar(max) NULL, 
	[State] varchar(max) NULL, 
	[Country] varchar(max) NULL, 
	[Region] varchar(max) NULL
);