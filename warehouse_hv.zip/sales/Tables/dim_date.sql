CREATE TABLE [sales].[dim_date] (

	[Date_ID] int NOT NULL, 
	[BusinessDate] datetime2(6) NULL, 
	[Business_Year] int NULL, 
	[Business_Month] int NULL, 
	[Business_Quarter] int NULL, 
	[Business_Week] int NULL
);