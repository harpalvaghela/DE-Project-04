CREATE TABLE [sales].[dim_segment] (

	[Segment_ID] int NOT NULL, 
	[Segment] varchar(max) NULL
);