CREATE TABLE [dbo].[loan_payments] (

	[payment_id] bigint NULL, 
	[loan_id] bigint NULL, 
	[payment_date] date NULL, 
	[payment_amount] bigint NULL
);