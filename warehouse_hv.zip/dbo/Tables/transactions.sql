CREATE TABLE [dbo].[transactions] (

	[transaction_id] varchar(8000) NULL, 
	[account_id] varchar(8000) NULL, 
	[transaction_date] varchar(8000) NULL, 
	[transaction_amount] varchar(8000) NULL, 
	[transaction_type] varchar(8000) NULL
);