CREATE TABLE [dbo].[customers] (

	[customer_id] bigint NULL, 
	[first_name] varchar(8000) NULL, 
	[last_name] varchar(8000) NULL, 
	[address] varchar(8000) NULL, 
	[city] varchar(8000) NULL, 
	[state] varchar(8000) NULL, 
	[zip] varchar(8000) NULL
);