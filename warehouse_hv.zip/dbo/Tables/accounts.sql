CREATE TABLE [dbo].[accounts] (

	[account_id] bigint NULL, 
	[customer_id] bigint NULL, 
	[account_type] varchar(8000) NULL, 
	[balance] float NULL
);