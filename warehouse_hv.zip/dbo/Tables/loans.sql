CREATE TABLE [dbo].[loans] (

	[loan_id] bigint NULL, 
	[customer_id] bigint NULL, 
	[loan_amount] float NULL, 
	[interest_rate] float NULL, 
	[loan_term] bigint NULL
);